# Viver de IA · design kit pra IAs externas

Pacote pra colar em **Claude.ai · ChatGPT · Cursor · Lovable · v0 · qualquer outra IA**
que aceite upload de arquivos ou ZIP.

## Como usar

### 1. Em Claude.ai / ChatGPT (aceita upload)
1. Abre chat novo
2. Anexa este ZIP inteiro (ou pasta descompactada)
3. Diz: "Use este design system para gerar o que eu pedir."
4. Pede o que quiser ("crie um email de welcome", "monta um post pra LinkedIn", etc.)

### 2. Em Lovable / v0 / Cursor (system prompt)
1. Cola o conteúdo de `system-prompt.md` no campo de system prompt ou custom instructions
2. Pede o que quiser
3. A IA vai seguir as regras do design system automaticamente

### 3. Em IDE com Claude Code instalado
Use o **plugin completo** com comandos slash em vez deste ZIP:
```
git clone https://github.com/rafaelmilagre7/viver-de-ia-ds.git
ln -s viver-de-ia-ds/plugins/viver-de-ia ~/.claude/plugins/
```

## O que tem no kit

```
/
├── README.md                ← este arquivo
├── system-prompt.md         ← prompt geral · cola em qualquer LLM
├── system-prompts/          ← sub-prompts por contexto
│   ├── email.md
│   ├── social.md
│   ├── landing.md
│   ├── brand.md
│   ├── deck.md
│   └── paid.md
├── tokens/                  ← design tokens
│   ├── tokens.json          ← machine-readable
│   ├── tokens.css           ← CSS variables
│   └── style.css            ← CSS completo da library (quando lib foi buildada)
├── logos/                   ← assets de marca PNG
│   ├── monogram-navy.png
│   ├── monogram-white.png
│   ├── wordmark-navy.png
│   ├── wordmark-white.png
│   ├── app-icon.png
│   ├── leaders-ai-conference.png
│   └── ...
└── examples/                ← HTML specimens prontos
    ├── email-welcome.html
    └── social-ig-post.html
```

## Princípios não-negociáveis (resumo · system-prompt.md tem completo)

1. **Paleta restrita** · branco · cinza · navy · preto · coral só destrutivo · sem gold/amarelo
2. **Pill canônica** · 11px · 500 · letter-spacing -0.004em · nowrap · sem dot · sem caps lock
3. **Geist single family** · italic em ênfase · letterspacing negativo em corpo
4. **Voz editorial** · operador-experiente · número ou citação · sem clichê IA
5. **Sparkles banido** · usar Compass · Award · Crown · Layers · MessageCircle
6. **Logo correta por contexto** · monogram pequeno · wordmark grande · app icon em profile

## Reference site canônico

Quando em dúvida sobre como algo deve parecer, consulte:
**https://github.com/rafaelmilagre7/viver-de-ia-ds** · 107 rotas vivas · 47 componentes · dark mode + WCAG AA completos.

## Suporte

Issues / dúvidas: https://github.com/rafaelmilagre7/viver-de-ia-ds/issues
